<?php

$a=12;
$b=19;
$result=$a+$a;
echo $result;

?>